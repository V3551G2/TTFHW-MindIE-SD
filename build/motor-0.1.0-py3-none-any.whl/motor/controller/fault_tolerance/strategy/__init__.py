# -*- coding: utf-8 -*-
# Copyright (c) Huawei Technologies Co., Ltd. 2025-2026. All rights reserved.
# MindIE is licensed under Mulan PSL v2.
# You can use this software according to the terms and conditions of the Mulan PSL v2.
# You may obtain a copy of Mulan PSL v2 at:
#         http://license.coscl.org.cn/MulanPSL2
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND,
# EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
# MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
# See the Mulan PSL v2 for more details.
"""
Fault tolerance strategy module - contains fault recovery strategies.
"""

__all__ = [
    "StrategyBase",
    "generate_strategy_map",
    "ScaleP2DStrategy",
    "LingquNetworkRecoverStrategy",
]

from .strategy import StrategyBase, generate_strategy_map
from .scale_p2d import ScaleP2DStrategy
from .lingqu_network_recover import LingquNetworkRecoverStrategy
