# Copyright (c) Huawei Technologies Co., Ltd. 2025-2026. All rights reserved.
# MindIE is licensed under Mulan PSL v2.
# You can use this software according to the terms and conditions of the Mulan PSL v2.
# You may obtain a copy of Mulan PSL v2 at:
#         http://license.coscl.org.cn/MulanPSL2
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND,
# EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
# MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
# See the Mulan PSL v2 for more details.

import os
import json
from typing import Any
from enum import Enum
from dataclasses import dataclass, field, asdict
from pathlib import Path

from motor.common.resources.instance import ParallelConfig, PDRole
from motor.config.tls_config import TLSConfig
from motor.common.utils.env import Env
from motor.common.utils.patch_check import safe_open
from motor.common.logger import get_logger, reconfigure_logging
from motor.config.config_utils import (
    ConfigKey, save_config_to_json, _update_tls_config, MGMT_TLS_CONFIG,
)
from motor.config.log_config import LoggingConfig

FILE_ENCODING = "utf-8"

PP = "pp_size"
TP = "tp_size"
DP = "dp_size"
BASIC_CONFIG_KEY = "basic_config"
MODEL_CONFIG_KEY = "model_config"
PARALLEL_CONFIG_KEY = "parallel_config"
MOTOR_NODE_MANAGER_CONFIG_KEY = "motor_nodemanger_config"
MOTOR_ENGINE_PREFILL_CONFIG_KEY = "motor_engine_prefill_config"
MOTOR_ENGINE_DECODE_CONFIG_KEY = "motor_engine_decode_config"
ENGINE_CONFIG_KEY = "engine_config"
KV_TRANSFER_CONFIG_KEY = "kv_transfer_config"
KV_CONNECTOR_KEY = "kv_connector"
MULTICONNECTOR = "MultiConnector"
KV_CONNECTOR_EXTRA_CONFIG_KEY = "kv_connector_extra_config"
CONNECTORS_KEY = "connectors"
KV_PORT_KEY = "kv_port"
LOOPUP_RPC_PORT_KEY = "lookup_rpc_port"
SERVER_LIST = "server_list"
DEVICE = 'device'
HARDWARE_TYPE_KEY = "hardware_type"
MODEL_NAME_KEY = "model_name"
ENABLE_MULTI_ENDPOINTS_KEY = "enable_multi_endpoints"


logger = get_logger(__name__)


class HardwareType(str, Enum):
    TYPE_800I_A2 = "800I-A2"
    TYPE_800I_A3 = "800I-A3"

    def __repr__(self) -> str:
        return str.__repr__(self.value)


@dataclass
class BasicConfig:
    """Basic configuration class"""

    # Job configuration
    job_name: str = Env.job_name
    role: PDRole = PDRole.ROLE_U
    model_name: str = ""
    hardware_type: HardwareType = HardwareType.TYPE_800I_A3

    # Heartbeat sending configuration
    heartbeat_interval_seconds: int = 1

    # Device information
    device_num: int = 0
    # Parallel configuration
    parallel_config: ParallelConfig = field(default_factory=ParallelConfig)
    # Multi-endpoints configuration
    enable_multi_endpoints: bool = True


@dataclass
class APIConfig:
    """API configuration class"""
    # http config
    pod_ip: str | None = field(default_factory=lambda: Env.pod_ip or "127.0.0.1")
    node_manager_port: int = 1026


@dataclass
class EndpointConfig:

    # EngineServer's number
    endpoint_num: int = 0

    # EngineServer's Port configuration
    base_port: int = 10000
    mgmt_ports: list[str] = field(default_factory=list)
    service_ports: list[str] = field(default_factory=list)


@dataclass
class SingleContainerNodemanagerConfig:
    single_container_flag: bool = False
    node_manager_port_offset: int | None = None
    base_port_offset: int | None = None
    device_offset: int | None = None
    device_num: int | None = None
    kv_port: int | None = None
    lookup_rpc_port: int | None = None
    dp_rpc_port: int | None = None

    @classmethod
    def from_json(cls, user_config_data: dict[str, Any]) -> 'SingleContainerNodemanagerConfig':
        config = cls()
        deploy_mode = user_config_data.get('motor_coordinator_config', {}).get(
            "scheduler_config", {}).get('deploy_mode', '')
        if not deploy_mode == 'pd_disaggregation_single_container' or not Env.role or Env.index is None:
            return config

        config.single_container_flag = True
        p_instances_num = user_config_data['motor_deploy_config']['p_instances_num']
        d_instances_num = user_config_data['motor_deploy_config']['d_instances_num']
        prefill_model_cfg = user_config_data[MOTOR_ENGINE_PREFILL_CONFIG_KEY][MODEL_CONFIG_KEY]
        decode_model_cfg = user_config_data[MOTOR_ENGINE_DECODE_CONFIG_KEY][MODEL_CONFIG_KEY]
        prefill_parallel_config = prefill_model_cfg[PARALLEL_CONFIG_KEY]
        decode_parallel_config = decode_model_cfg[PARALLEL_CONFIG_KEY]
        p_dp_size = prefill_parallel_config[DP]
        p_tp_size = prefill_parallel_config[TP]
        p_pp_size = prefill_parallel_config[PP]
        d_dp_size = decode_parallel_config[DP]
        d_tp_size = decode_parallel_config[TP]
        d_pp_size = decode_parallel_config[PP]

        index = int(Env.index)
        if Env.role == 'prefill':
            config.node_manager_port_offset = index
            config.base_port_offset = index * d_dp_size * 2
            config.device_offset = index * p_dp_size * p_tp_size * p_pp_size
            config.device_num = p_dp_size * p_tp_size * p_pp_size
            kv_port_offset = config.device_offset
            lookup_rpc_port_offset = index
            dp_rpc_port_offset = index
        else:
            config.node_manager_port_offset = p_instances_num * p_dp_size + index
            config.base_port_offset = (p_instances_num * p_dp_size + index * d_dp_size) * 2
            config.device_offset = p_instances_num * p_dp_size * p_tp_size * p_pp_size + \
                    index * d_dp_size * d_tp_size * d_pp_size
            config.device_num = d_dp_size * d_tp_size * d_pp_size
            kv_port_offset = config.device_offset
            lookup_rpc_port_offset = p_instances_num + index
            dp_rpc_port_offset = p_instances_num + index

        kv_config = user_config_data[MOTOR_ENGINE_PREFILL_CONFIG_KEY][ENGINE_CONFIG_KEY].get(KV_TRANSFER_CONFIG_KEY, {})
        if kv_config:
            if kv_config[KV_CONNECTOR_KEY] == MULTICONNECTOR:
                connectors = kv_config[KV_CONNECTOR_EXTRA_CONFIG_KEY][CONNECTORS_KEY]
                config.kv_port = int(connectors[0][KV_PORT_KEY]) + kv_port_offset
                config.lookup_rpc_port = int(connectors[1][LOOPUP_RPC_PORT_KEY]) + lookup_rpc_port_offset
            else:
                config.kv_port = int(kv_config[KV_PORT_KEY]) + kv_port_offset

        config.dp_rpc_port = int(prefill_parallel_config["dp_rpc_port"]) + dp_rpc_port_offset

        return config


@dataclass
class NodeManagerConfig:
    """ Global configuration singleton for node manager """

    # Configuration sections
    api_config: APIConfig = field(default_factory=APIConfig)
    mgmt_tls_config: TLSConfig = field(default_factory=TLSConfig)
    endpoint_config: EndpointConfig = field(default_factory=EndpointConfig)
    basic_config: BasicConfig = field(default_factory=BasicConfig)
    logging_config: LoggingConfig = field(default_factory=LoggingConfig)
    single_container_config: SingleContainerNodemanagerConfig = field(default_factory=SingleContainerNodemanagerConfig)

    # Internal fields
    config_path: str | None = field(default=None, init=False)
    last_modified: float | None = field(default=None, init=False)

    def __post_init__(self):
        """Validate configuration after initialization"""
        # Set internal paths with defaults only if not already set (e.g., by from_json)
        if not hasattr(self, 'config_path') or self.config_path is None:
            self.config_path = Env.user_config_path or Env.config_path

        # Set last modified time if config file exists
        try:
            if self.config_path and os.path.exists(self.config_path):
                self.last_modified = os.path.getmtime(self.config_path)
        except (OSError, IOError):
            # Ignore errors when checking file modification time
            pass

        self.validate_config()

    @classmethod
    def from_json(cls, config_path: str | None = None) -> 'NodeManagerConfig':
        """Load configuration from user_config.json"""
        if config_path is None:
            config_path = Env.user_config_path or Env.config_path

        config_path_obj = Path(config_path) if config_path else None
        logger.info("Loading configuration files: config=%s", config_path_obj)

        config = cls()
        config.config_path = config_path

        config_data = {}
        raw = None
        if config_path_obj is not None and os.path.exists(str(config_path_obj)):
            with safe_open(str(config_path_obj), "r") as f:
                raw = json.load(f)
            logger.info("Successfully loaded config file: %s", config_path_obj)

            config.single_container_config = SingleContainerNodemanagerConfig.from_json(raw)

            if isinstance(raw, dict):
                config_data = cls._load_node_manager_config_data(raw)
            else:
                config_data = raw

            cls._update_from_config_data(config, config_data)
        else:
            logger.warning("Config file does not exist, using default configuration: %s", config_path_obj)

        cls._set_device_count_from_config(config, raw)

        config.validate_config()

        if config_path_obj is not None and config_path_obj.exists():
            config.last_modified = config_path_obj.stat().st_mtime

        logger.info("Configuration loading completed")
        return config

    @classmethod
    def _load_node_manager_config_data(cls, user_cfg: dict[str, Any]) -> dict[str, Any]:
        """Load node_manager_config from engine config based on role"""
        engine_config_key = None
        if Env.role == "prefill":
            engine_config_key = MOTOR_ENGINE_PREFILL_CONFIG_KEY
        elif Env.role == "decode":
            engine_config_key = MOTOR_ENGINE_DECODE_CONFIG_KEY
        
        if not engine_config_key or engine_config_key not in user_cfg:
            return user_cfg
        
        engine_config = user_cfg[engine_config_key]
        if "motor_nodemanger_config" in engine_config:
            config_data = engine_config.get("motor_nodemanger_config", {})
        else:
            config_data = {}
        
        if BASIC_CONFIG_KEY not in config_data:
            config_data[BASIC_CONFIG_KEY] = {}
        
        config_data[BASIC_CONFIG_KEY][MODEL_NAME_KEY] = \
            engine_config[MODEL_CONFIG_KEY][MODEL_NAME_KEY]
        config_data[BASIC_CONFIG_KEY][HARDWARE_TYPE_KEY] = user_cfg["motor_deploy_config"][HARDWARE_TYPE_KEY]
        
        if Env.role in ("prefill", "decode"):
            config_data[BASIC_CONFIG_KEY]["parallel_config"] = \
                engine_config[MODEL_CONFIG_KEY][PARALLEL_CONFIG_KEY]
            enable_multi_endpoints = engine_config.get(ENABLE_MULTI_ENDPOINTS_KEY, True)
            config_data[BASIC_CONFIG_KEY][ENABLE_MULTI_ENDPOINTS_KEY] = enable_multi_endpoints
        
        _update_tls_config([MGMT_TLS_CONFIG], config_data, user_cfg)
        
        return config_data

    @classmethod
    def _update_from_config_data(cls, config: 'NodeManagerConfig', cfg: dict[str, Any]):
        """Update configuration from config JSON data"""
        # Helper function to update config object from dict
        def update_config_from_dict(config_obj, config_dict):
            """Update configuration object fields from dictionary, only for existing keys"""
            for key, value in config_dict.items():
                if hasattr(config_obj, key):
                    setattr(config_obj, key, value)

        # Update configuration sections if they exist in JSON
        if "logging_config" in cfg:
            update_config_from_dict(config.logging_config, cfg["logging_config"])

        if "api_config" in cfg:
            update_config_from_dict(config.api_config, cfg["api_config"])

        if 'mgmt_tls_config' in cfg:
            update_config_from_dict(config.mgmt_tls_config, cfg['mgmt_tls_config'])

        if "endpoint_config" in cfg:
            update_config_from_dict(config.endpoint_config, cfg["endpoint_config"])

        if BASIC_CONFIG_KEY in cfg:
            basic_cfg = cfg[BASIC_CONFIG_KEY]
            update_config_from_dict(config.basic_config, basic_cfg)
            # Handle parallel_config specially
            if "parallel_config" in basic_cfg:
                pc = basic_cfg["parallel_config"]
                if isinstance(pc, dict):
                    config.basic_config.parallel_config = ParallelConfig(**pc)

        if config.single_container_config.single_container_flag:
            config.api_config.node_manager_port += config.single_container_config.node_manager_port_offset
            config.endpoint_config.base_port += config.single_container_config.base_port_offset

        # Set role from environment
        try:
            role = Env.role
            config.basic_config.role = PDRole(role)
            logger.info("Role from environment: %s", role)
            logger.info("Role from config: %s", config.basic_config.role)
        except ValueError as e:
            raise ValueError("Invalid role value from environment") from e

    @classmethod
    def _set_device_count_from_config(cls, config: 'NodeManagerConfig', raw: dict | None):
        """
        Set device count from config based on role.
        For prefill role, use p_pod_npu_num.
        For decode role, use d_pod_npu_num.
        For single_container mode, use parallel_config.world_size instead.
        """
        try:
            if not isinstance(raw, dict) or "motor_deploy_config" not in raw:
                logger.warning("No motor_deploy_config found, using default device configuration")
                config.basic_config.device_num = 0
                config.endpoint_config.endpoint_num = 0
                config.endpoint_config.service_ports = []
                config.endpoint_config.mgmt_ports = []
                return

            if config.single_container_config.single_container_flag:
                cls._set_device_count_for_single_container(config)
            else:
                cls._set_device_count_for_normal_mode(config, raw)

            cls._generate_endpoint_ports(config)
            
        except Exception as e:
            logger.error("Failed to get device count from config: %s", e)
            config.basic_config.device_num = 0
            config.endpoint_config.endpoint_num = 0
            config.endpoint_config.service_ports = []
            config.endpoint_config.mgmt_ports = []

    @classmethod
    def _set_device_count_for_single_container(cls, config: 'NodeManagerConfig'):
        """Set device count for single container mode using parallel_config.world_size"""
        device_count = config.basic_config.parallel_config.world_size
        if device_count > 0:
            logger.info("Single container mode: using world_size %d from parallel_config", device_count)
            config.basic_config.device_num = device_count
        else:
            logger.warning("Single container mode: world_size is 0, falling back to single_container_config.device_num")
            config.basic_config.device_num = config.single_container_config.device_num or 0

    @classmethod
    def _set_device_count_for_normal_mode(cls, config: 'NodeManagerConfig', raw: dict):
        """Set device count for normal mode using motor_deploy_config"""
        deploy_config = raw["motor_deploy_config"]
        if Env.role == "prefill":
            device_count = deploy_config.get("p_pod_npu_num", 0)
        elif Env.role == "decode":
            device_count = deploy_config.get("d_pod_npu_num", 0)
        else:
            device_count = 0
        
        if device_count > 0:
            logger.info("Using %d devices from config for role %s", device_count, Env.role)
            config.basic_config.device_num = device_count
        else:
            logger.warning("No device count found in config for role %s", Env.role)
            config.basic_config.device_num = 0

    @classmethod
    def _generate_endpoint_ports(cls, config: 'NodeManagerConfig'):
        """
        Calculate endpoint number based on tensor parallel & pipeline parallel config.
        Example: tp=2, pp=4 => 8 devices per pod
        """
        dp = config.basic_config.parallel_config.dp_size
        devices_per_dp = config.basic_config.parallel_config.tp_size * config.basic_config.parallel_config.pp_size

        # only enable multi endpoints should check device count
        if (
            (config.basic_config.enable_multi_endpoints and config.basic_config.device_num < devices_per_dp)
            or dp < 1
        ):
            raise ValueError(
                f"Device count ({config.basic_config.device_num}) must bigger than "
                f"or equal to devices per dp ({devices_per_dp}) "
                f"and dp must be bigger than 0"
            )

        if not config.basic_config.enable_multi_endpoints:
            config.endpoint_config.endpoint_num = 1
        else:
            config.endpoint_config.endpoint_num = min(dp, config.basic_config.device_num // devices_per_dp)
        config.endpoint_config.service_ports = [
            str(config.endpoint_config.base_port + i * 2)
            for i in range(config.endpoint_config.endpoint_num)
        ]
        config.endpoint_config.mgmt_ports = [
            str(config.endpoint_config.base_port + i * 2 + 1)
            for i in range(config.endpoint_config.endpoint_num)
        ]

        logger.info(
            "Generate endpoint ports successfully: endpoint_num: %d, mgmt_ports: %s, service_ports: %s.",
            config.endpoint_config.endpoint_num,
            config.endpoint_config.mgmt_ports,
            config.endpoint_config.service_ports,
        )

    def validate_config(self) -> None:
        """Validate the validity of configuration values"""
        errors = []

        # Validate API configuration
        if self.api_config.node_manager_port <= 0 or self.api_config.node_manager_port > 65535:
            errors.append("node_manager_port must be in range 1-65535")

        # Validate network configuration
        if self.endpoint_config.base_port < 0 or self.endpoint_config.base_port > 65535:
            errors.append("base_port must be in range 0-65535")

        if self.endpoint_config.endpoint_num < 0:
            errors.append("endpoint_num cannot be negative")

        # Validate device configuration
        if self.basic_config.heartbeat_interval_seconds <= 0:
            errors.append("heartbeat_interval_seconds must be greater than 0")

        # Validate logging configuration
        valid_log_levels = ['DEBUG', 'INFO', 'WARNING', 'ERROR']
        if self.logging_config.log_level.upper() not in valid_log_levels:
            errors.append(f"log_level must be one of: {', '.join(valid_log_levels)}")

        if self.logging_config.log_max_line_length <= 0:
            errors.append("log_max_line_length must be greater than 0")

        if errors:
            error_msg = "Configuration validation failed:\n" + "\n".join(f"  - {error}" for error in errors)
            logger.error(error_msg)
            raise ValueError(error_msg)

    def reload(self) -> bool:
        """Reload configuration from files"""
        if not self.config_path or not os.path.exists(self.config_path):
            logger.warning("Configuration file path does not exist, cannot reload")
            return False

        try:
            # Check if config file has been modified
            current_mtime = os.path.getmtime(self.config_path)
            if self.last_modified and current_mtime <= self.last_modified:
                logger.debug("Configuration file not modified, skipping reload")
                return True

            logger.info("Configuration file change detected, reloading...")
            new_config = NodeManagerConfig.from_json(self.config_path)

            # Update current configuration
            for field_name in self.__dataclass_fields__:
                if field_name not in ['config_path', 'last_modified']:
                    setattr(self, field_name, getattr(new_config, field_name))

            self.last_modified = current_mtime

            reconfigure_logging(self.logging_config)

            logger.info("NodeManager configuration reload successful")
            return True

        except Exception as e:
            logger.error("Failed to reload NodeManager configuration: %s", e)
            return False

    def to_dict(self) -> dict[str, Any]:
        """Convert configuration to dictionary with grouped structure"""

        # Use dataclasses.asdict to automatically serialize all config objects
        config_dict = asdict(self)

        # Handle BaseModel objects that can't be serialized by asdict
        if hasattr(self.basic_config.parallel_config, 'model_dump'):
            config_dict['basic_config']['parallel_config'] = self.basic_config.parallel_config.model_dump()

        # Remove internal fields that shouldn't be in the output
        config_dict.pop('config_path', None)
        config_dict.pop('last_modified', None)

        return config_dict

    def save_to_json(self, config_path: str | None = None) -> bool:
        """Save configuration to JSON files"""
        save_config_path = config_path or self.config_path

        if not save_config_path:
            logger.error("Save paths not specified")
            return False

        try:
            # Save config file
            config_dict = self.to_dict()
            save_config_to_json(
                save_config_path,
                ConfigKey.MOTOR_NODEMANAGER,
                config_dict,
                file_encoding=FILE_ENCODING,
                component_name="node manager",
            )
            logger.info("Configuration saved to: %s", save_config_path)
            return True
        except Exception as e:
            logger.error("Failed to save configuration: %s", e)
            return False

    def get_config_summary(self) -> str:
        """Get configuration summary information"""
        separator = "=" * 80
        title = " " * 22 + "NodeManager Configuration Summary"
        return (
            f"{separator}\n"
            f"{title}\n"
            f"{separator}\n"
            "  Logging Configuration:\n"
            f"    ├─ Log Level:           {self.logging_config.log_level}\n"
            f"    ├─ Log File:            {self.logging_config.host_log_dir}\n"
            f"    └─ Log Max Line Length: {self.logging_config.log_max_line_length}\n"
            "\n"
            "  Network Configuration:\n"
            f"    ├─ Node Manager Port:   {self.api_config.node_manager_port}\n"
            f"    ├─ Pod IP:              {self.api_config.pod_ip}\n"
            f"    └─ TLS:                 {'Enabled' if self.mgmt_tls_config.enable_tls else 'Disabled'}\n"
            "\n"
            "  Basic Configuration:\n"
            f"    ├─ Job Name:            {self.basic_config.job_name}\n"
            f"    ├─ Role:                {self.basic_config.role}\n"
            f"    ├─ Model:               {self.basic_config.model_name}\n"
            f"    ├─ Device Count:        {self.basic_config.device_num}\n"
            f"    ├─ Multi Endpoints:     {self.basic_config.enable_multi_endpoints}\n"
            f"    ├─ Endpoint Count:      {self.endpoint_config.endpoint_num}\n"
            f"    └─ Hardware Type:       {self.basic_config.hardware_type}\n"
            "\n"
            "  Parallel Configuration:\n"
            f"    ├─ TP Size:          TP={self.basic_config.parallel_config.tp_size}\n"
            f"    ├─ PP Size:          PP={self.basic_config.parallel_config.pp_size}\n"
            f"    ├─ DP Size:          DP={self.basic_config.parallel_config.dp_size}\n"
            f"    ├─ EP Size:          EP={self.basic_config.parallel_config.ep_size}\n"
            f"    ├─ SP Size:          SP={self.basic_config.parallel_config.sp_size}\n"
            f"    └─ World Size:       World Size={self.basic_config.parallel_config.world_size}\n"
            f"{separator}"
        )
