# Copyright (c) Huawei Technologies Co., Ltd. 2025-2026. All rights reserved.
# MindIE is licensed under Mulan PSL v2.
# You can use this software according to the terms and conditions of the Mulan PSL v2.
# You may obtain a copy of Mulan PSL v2 at:
#         http://license.coscl.org.cn/MulanPSL2
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND,
# EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
# MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
# See the Mulan PSL v2 for more details.

from motor.common.logger import get_logger
from motor.config.endpoint import EndpointConfig
from motor.engine_server.factory.config_factory import ConfigFactory
from motor.engine_server.factory.endpoint_factory import EndpointFactory
from motor.engine_server.utils.prometheus import setup_multiprocess_prometheus

logger = get_logger(__name__)


def main():
    # Execute setup_multiprocess_prometheus before importing Endpoint to ensure
    # PROMETHEUS_MULTIPROC_DIR is detected when Prometheus low-level code creates ValueClass.
    setup_multiprocess_prometheus()

    from motor.engine_server.core.infer_endpoint import InferEndpoint
    from motor.engine_server.core.mgmt_endpoint import MgmtEndpoint

    endpoint_config = EndpointConfig.init_endpoint_config()
    config_factory = ConfigFactory(endpoint_config=endpoint_config)
    config = config_factory.parse()
    logger.info(f"successfully parsed {endpoint_config.engine_type} engine configuration")

    mgmt_endpoint: MgmtEndpoint = MgmtEndpoint(config)
    infer_endpoint: InferEndpoint = EndpointFactory().get_infer_endpoint(config)

    mgmt_endpoint.run()
    infer_endpoint.run()
    infer_endpoint.wait()

    logger.info("shutting down endpoints and child processes...")
    mgmt_endpoint.shutdown()
    infer_endpoint.shutdown()
    logger.info("endpoints and child processes shut down")

if __name__ == "__main__":
    main()
